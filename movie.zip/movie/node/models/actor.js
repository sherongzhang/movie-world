const mongoose = require("./mongoose");

const actorSchema = mongoose.Schema({
    name:String,
    birthday:String,
    introduce:String,
    production:String,
    photo:String
});

var actor = mongoose.model("actor",actorSchema);

module.exports = actor ;
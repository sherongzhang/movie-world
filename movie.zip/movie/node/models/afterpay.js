var mongoose = require("./mongoose");

var paySchema = mongoose.Schema({
    movie: String,
    buyer: String,
    seat: Array
});

var Pay = mongoose.model("pay", paySchema);

module.exports = Pay;
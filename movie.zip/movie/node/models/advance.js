//电影预告
var mongoose = require("./mongoose");

var advanceSchema = mongoose.Schema({
    movie:String,
    poster:String,
    time:String
});

var Advance = mongoose.model("advance", advanceSchema);

module.exports = Advance;
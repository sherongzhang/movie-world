const url = "/www/server/nvm/versions/node/v12.18.3/lib/node_modules/"
var mongoose = require( url + "mongoose");

mongoose
    .connect("mongodb://localhost/block")
    .then(() => {
        console.log("数据库连接成功");
    })
    .catch((err) => {
        console.log("数据库连接失败", err);
    });


module.exports = mongoose

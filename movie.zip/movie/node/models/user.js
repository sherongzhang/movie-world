var mongoose = require("./mongoose");

var userSchema = mongoose.Schema({
    name:String,     
    phone:Number,
    password:String,
    headImg:String,
    backgroundImg:String,
    introduce:String,
    collectId:Array, //收藏
    contentId:Array, //影评
    pay:Array,
    type:Array
});

var User = mongoose.model("user", userSchema);

module.exports = User;
const url = "/www/server/nvm/versions/node/v12.18.3/lib/node_modules/"
const jwt = require( url + "jsonwebtoken");
const JWT_STRING = 'MOVIEJWT'; //密钥

class Jwt {
    constructor(data) {
        this.data = data
    }
    //生成Token
    generateToken() {
        let params = this.data;
        let createTime = Math.floor(Date.now() / 1000);
        let token = jwt.sign({
            params,
            exp: createTime + 60 * 10000
        }, JWT_STRING);
        return token
    }
    //校验Token是否过期
    verifyToken() {
        let token = this.data;
        let res
        try {
            let result = jwt.verify(token, JWT_STRING) || {}
            let { exp = 0 } = result, current = Math.floor(Date.now() / 1000)
            if (current <= exp) {
                res = result || {};
            }
        } catch (e) {
            res = 'err';
            return res
        }
        return res
    }
}
module.exports = Jwt;
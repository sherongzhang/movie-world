const mongoose = require("./mongoose");

const movieSchema = mongoose.Schema({
    movie:String,
    time:String,
    star:Number,
    intro:String, //电影简介
    poster:String,//电影海报
    actor:Array,
    price:Number,
    director:Array
});

var movie = mongoose.model("movie",movieSchema);

module.exports = movie ;

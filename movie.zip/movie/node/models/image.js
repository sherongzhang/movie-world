const mongoose = require("./mongoose");

const imageSchema = mongoose.Schema({
    user:String,
    imageAddress:String, //图片地址
});

var image = mongoose.model("movie",imageSchema);

module.exports = image ;

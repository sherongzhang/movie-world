const mongoose = require("./mongoose");

const filmReviewSchema = mongoose.Schema({
    author:String,
    content:String,
    headImg:String,
    comment:Array,
    movie:String,
    title:String,
    movie:String,
    time:String,
    like:Number,
    poster:Array,
    authorId:String
});

var filmReview = mongoose.model("filmreview", filmReviewSchema);

module.exports = filmReview;

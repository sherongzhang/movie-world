const url = "/www/server/nvm/versions/node/v12.18.3/lib/node_modules/"
const express = require( url + "express");
const app = express();
const User = require("./models/user");
const Actor = require("./models/actor");
const Movie = require("./models/movie");
//const Review = require("./models/review");
const Advance = require("./models/advance");
const FilmReview = require("./models/filmreview");
const Pay = require("./models/afterpay")
const myJwt = require("./models/jwt.js");
const bodyParser = require(  url + "body-parser");
const multer = require(  url + "multer");
const upload = multer({ dest: "public/uploads/" });
const fs = require("fs");
const path = require("path");
const mongoose = require( url + 'mongoose');
const request = require( url + 'request'); // request模块，http请求 npm i request
//允许跨域
app.all("*", (req, res, next) => {
    //设置允许跨域的域名，*代表允许任意域名跨域
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Access-Control-Allow-Methods', '*');
    res.header('Content-Type', 'application/json;charset=utf-8');
    next();
})

//解析至body 可以使用body-parser中间件
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.get("/", (req, res) => {
    res.send("欢迎登录后台")
})
//登录接口
app.post('/login', (req, res) => {
    var data = req.body;
    var phoneReg = /(^1[3|4|5|7|8|9]\d{9}$)/;
    if (phoneReg.test(req.body.phone) == true) {
        if (data.phone !== "" && data.password !== "") {
            User.findOne({ phone: data.phone }, (err, result) => {
                if (err) throw err
                if (!result) {
                    res.json({
                        code: 201,
                        msg: "该用户不存在"
                    })
                } else {
                    if (result.password === data.password) {
                        let Jwt = new myJwt(data);
                        let token = Jwt.generateToken();
                        res.json({
                            code: 200,
                            msg: "登录成功",
                            Token: token,
                            id: result._id,
                            phone: result.phone,
                            username: result.name,
                            userintroduce: result.introduce,//介绍
                            userimg: result.headImg,//头像
                            userbackground: result.backgroundImg,//主页背景
                            type: result.type
                        })
                    } else {
                        res.json({
                            code: 202,
                            msg: "密码错误"
                        })
                    }
                }
            })
        } else {
            res.json({
                code: 203,
                msg: "账号、密码不能为空"
            })
        }
    }
    else {
        res.json({
            code: 204,
            msg: "账号格式错误"
        })
    }

})
//注册接口
app.post("/register", (req, res) => {
    let data = req.body;
    let introduce = headImg = backgroundImg = "";
    let contentId = collectId = payId = commentId = type = [];
    data.introduce = introduce = "介绍一下自己"; //介绍
    data.headImg = headImg; //头像
    data.backgroundImg = backgroundImg; //背景
    data.collectId = collectId; //存储收藏夹id
    data.contentId = contentId; //发布的影评id
    data.commentId = commentId; //用户评论
    data.payId = payId; //订购
    data.type = type;   //喜欢的类型
    var phoneReg = /(^1[3|4|5|7|8|9]\d{9}$)/ //手机正则
    //判断用户是否符合
    if (phoneReg.test(data.phone) == true) {
        User.findOne({ phone: data.phone }, (err, result) => {
            if (err) throw err
            if (!result) {
                let newUser = new User(data)
                newUser.save((err) => {
                    if (err) throw err
                    res.json({
                        code: 200,
                        msg: "注册成功"
                    })
                })
            }
            else {
                res.json({
                    code: 201,
                    msg: "该用户已存在"
                })
            }
        })
    }
    else {
        res.json({
            code: 202,
            msg: "账号格式不正确"
        })
    }

})
//
app.get("/my", (req, res) => {
    let Jwt = new myJwt(req.query.token);
    let verifyToken = Jwt.verifyToken();
    if (verifyToken == "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        })
    }
    else {
        var phone = verifyToken.params.phone;
        User.findOne({ phone: phone }, (err, result) => {
            if (err) throw err
            res.json({
                code: 200,
                result: result
            })
        })
    }
})
//修改个人信息
app.post("/usermsg", (req, res) => {
    var Jwt = new myJwt(req.body.token);
    let verifyToken = Jwt.verifyToken();
    if (verifyToken === "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        });
    } else {
        if (req.body.isIntroduce) {
            User.findByIdAndUpdate(req.body.id, { $set: { introduce: req.body.introduce } }, (err) => {
                if (err) throw err
                res.json({
                    code: 200,
                    msg: "个人介绍修改成功",
                    introduce: req.body.introduce
                });
            })
        }
        else if (req.body.isName) {
            User.findByIdAndUpdate(req.body.id, { $set: { name: req.body.name } }, (err) => {
                if (err) throw err
                res.json({
                    code: 200,
                    msg: "昵称修改成功",
                    name: req.body.name
                })
            })
        }
        else if (req.body.isChangepassword) {
            User.findById(req.body.id, (err, result) => {
                if (err) throw err
                if (req.body.password === result.password && req.body.password !== req.body.changepassword) {
                    User.update({ password: req.body.password }, { password: req.body.changepassword }, (err) => {
                        if (err) throw err
                        res.json({
                            code: 200,
                            msg: "修改成功"
                        })
                    })
                } else {
                    res.json({
                        code: 201,
                        msg: "密码错误"
                    })
                }
            })
        }
        else {
            res.send({
                code: 202,
                msg: "修改失败"
            })
        }
    }
})
app.post("/type", (req, res) => {
    var Jwt = new myJwt(req.body.token);
    let verifyToken = Jwt.verifyToken();
    if (verifyToken === "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        });
    } else {
        User.findByIdAndUpdate(req.body.id, { $set: { type: req.body.type } }, err => {
            if (err) throw err
        });
        res.json({
            code: 200
        })
    }
})

//用户确认
app.post("/user", (req, res) => {
    var Jwt = new myJwt(req.body.token);
    let verifyToken = Jwt.verifyToken();
    if (verifyToken === "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        });
    } else {
        res.json({
            code: 200
        })
    }
})
//存储图片
app.post("/image", upload.single("file"), (req, res) => {
    let file = req.file;
    let uploads = file.path;
    let ext = path.extname(file.originalname);
    let newName = "" + (new Date().getTime()) + Math.round(Math.random() * 10000) + ext;
    let newPath = "/public/images/" + newName;
    let fileData = fs.readFileSync(uploads); //同步读取文件
    fs.writeFileSync(__dirname + newPath, fileData);
    //fs.writeFile('文件路径'，'要写入的内容'，['编码']，'回调函数');
    if (newPath) {
        res.json({
            code: 200,
            newPath: "images/" + newName
        })
    }
})
//存储地址
app.post("/path", (req, res) => {
    if (req.body.head) {
        User.findByIdAndUpdate(req.body.id, { $set: { headImg: req.body.newPath } }, (err, result) => {
            if (err) throw err
            res.json({
                code: 200,
                msg: "图片已更换",
                path: req.body.newPath
            })
        });
    }
    else if (req.body.background) {
        User.findByIdAndUpdate(req.body.id, { $set: { backgroundImg: req.body.newPath } }, (err, result) => {
            if (err) throw err
            res.json({
                code: 200,
                msg: "图片已更换",
                path: req.body.newPath
            })
        });
    }
    else {
        res.json({
            code: 202,
            msg: "图片更换失败"
        })
    }
})


//电影收藏
app.post("/collect", (req, res) => {
    var Jwt = new myJwt(req.body.token);
    let verifyToken = Jwt.verifyToken();//校验token
    if (verifyToken === "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        })
    } else {
        var phone = verifyToken.params.phone;
        if (req.body.isLike) {
            User.findOneAndUpdate({ phone: phone }, { $push: { collectId: req.body.id } }, (err) => {
                if (err) throw err
                res.json({
                    code: 200,
                    msg: "收藏成功"
                })
            })
        }
        else {
            User.findOneAndUpdate({ phone: phone }, { $pull: { collectId: req.body.id } }, (err) => {
                if (err) throw err
                res.json({
                    code: 202,
                    msg: "取消收藏"
                })
            })
        }

    }

})
//判断收藏
app.post("/isCollect", (req, res) => {
    var Jwt = new myJwt(req.body.token);
    //var id = req.body.id
    let verifyToken = Jwt.verifyToken();//校验token
    if (verifyToken === "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        })
    } else {
        var phone = verifyToken.params.phone;
        User.findOne({ phone: phone }, (err, result) => {
            if (err) throw err
            if (result.collectId.find(() => {
                return id = req.body.id
            })) {
                res.json({
                    code: 200,
                    msg: "已收藏"
                })
            } else {
                res.json({
                    code: 201,
                    msg: "未收藏"
                })
            }



        })
    }
})
app.post("/myCollect", (req, res) => {
    var Jwt = new myJwt(req.body.token);
    let verifyToken = Jwt.verifyToken();//校验token
    if (verifyToken === "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        })
    } else {
        var phone = verifyToken.params.phone;
        User.findOne({ phone: phone }, (err, result) => {
            if (err) throw err
            res.json({
                code: 200,
                collectId: result.collectId
            })
        })
    }
})
app.post("/movieCollect", (req, res) => {
    var id = mongoose.Types.ObjectId(req.body.id);
    Movie.findById(id, (err, result) => {
        console.log(result)
        if (err) throw err
        res.json({
            code: 200,
            movie: result
        })
    })
})
//影评接口
app.post("/filmReview", (req, res) => {
    let contentId = req.body.contentId;
    console.log(req.body.contentId)
    var Jwt = new myJwt(req.body.token);
    let verifyToken = Jwt.verifyToken();
    if (verifyToken == "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        });
    } else {
        if (!contentId) {
            var date = new Date();
            var time = date.getFullYear() + "年" + (date.getMonth() + 1) + "月" + date.getDay() + "日";
            let data = {
                author: req.body.username,
                authorId: req.body.id,
                content: req.body.content,
                headImg: req.body.headImg,
                movie: req.body.movie,
                title: req.body.title,
                time: time,
                like: 0,
                poster: []
            }
            let newFilmReview = new FilmReview(data);
            if (req.body.content == "" || req.body.name == "" || req.body.id == "") {
                res.json({
                    code: 202,
                    msg: "发布失败，内容不能为空"
                })
            }
            else {
                newFilmReview.save((err, result) => {
                    if (err) throw err
                    res.json({
                        code: 200,
                        msg: "发布成功",
                        contentId: result._id
                    })
                    //将文章id录取用户信息contentId数组里
                    User.findByIdAndUpdate(req.body.id, { $push: { contentId: result._id } }, err => {
                        if (err) throw err

                    })
                })
            }
        }
        else {
            var id = mongoose.Types.ObjectId(req.body.contentId);
            User.findByIdAndUpdate(req.body.id, { $pull: { contentId: id } }, (err, result) => {
                if (err) throw err
                FilmReview.findByIdAndDelete(contentId, err => {
                    if (err) throw err
                    res.json({
                        code: 200,
                        msg: "已删除",
                        id: contentId
                    })
                })
            });
        }
    }
})
app.get("/review", (req, res) => {
    FilmReview.find({}, (err, result) => {
        if (err) throw err
        res.json({
            code: 200,
            result: result
        })
    })
})
app.post("/otherReview", (req, res) => {
    var date = new Date()
    var time = date.getFullYear() + "年" + (date.getMonth() + 1) + "月" + date.getDay() + "日"
    var Jwt = new myJwt(req.body.token);
    let verifyToken = Jwt.verifyToken();
    if (verifyToken == "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        });
    } else {
        var phone = verifyToken.params.phone;
        User.findOne({ phone: phone }, (err, result) => {
            if (err) throw err
            var comment = {
                name: result.name,
                time: time,
                headImg: result.headImg,
                content: req.body.content
            }
            FilmReview.findByIdAndUpdate(req.body.id, { $push: { comment: comment } }, err => {
                if (err) throw err
                res.json({
                    code: 200,
                    result: result,
                    msg: "发布成功"
                })
            })
        })
    }

})
app.post("/reviewPoster", (req, res) => {
    FilmReview.findByIdAndUpdate(req.body.id, { $push: { poster: req.body.path } }, err => {
        if (err) throw err
        res.json({
            code: 200,

        })
    })
})
app.post("/myReviewId", (req, res) => {
    User.findById(req.body.id, (err, result) => {
        if (err) throw err
        res.json({
            code: 200,
            contentId: result.contentId
        })
    })
})
app.post("/myReview", (req, res) => {
    FilmReview.findById(req.body.id, (err, result) => {
        if (err) throw err
        if (result == []) {
            res.json({
                code: 201,
                msg: "暂未发布"
            })
        }
        res.json({
            code: 200,
            result: result
        })
    })
})
//演员 
app.get("/actor", (req, res) => {
    Actor.find({}, (err, result) => {
        if (err) throw err
        res.json({
            code: 200,
            result: result
        })
    })
})
app.get("/movieActor", (req, res) => {
    Actor.findById(req.query.id, (err, result) => {
        if (err) throw err
        res.json({
            code: 200,
            actor: result
        })
    })
})
//电影
app.get("/movie", (req, res) => {
    Movie.find({}, (err, result) => {
        if (err) {
            res.json({
                code: 201,
                msg: "连接错误"
            })
            throw err
        }
        res.json({
            code: 200,
            result: result
        })
    })
})
app.get("/movieId", (req, res) => {
    Movie.findById(req.query.id, (err, result) => {
        if (err) throw err
        res.json({
            code: 200,
            result: result
        })
    })
})
//搜索接口
app.post("/search", (req, res) => {
    let value = req.body.value
    if (value !== "") {
        request.get(`http://v.juhe.cn/movie/index?key=c4009799d19cc38986e3482ad3eb8b58&title=${encodeURI(value)}&smode=0`, (err, response, body) => {
            if (err) throw err
            let MovieList = []
            MovieList.push(body);
            if (JSON.parse(MovieList[0]).error_code !== 0) {
                res.json({
                    code: 201,
                    msg: "无搜索结果"
                });
            }
            res.json({
                code: 200,
                movieList: MovieList
            })
        })
    }
    else {
        res.json({
            code: 202,
            msg: "搜索内容不能为空"
        });
    }
})
//订购与退票
app.post("/pay", (req, res) => {
    var Jwt = new myJwt(req.body.token);
    let verifyToken = Jwt.verifyToken();
    if (verifyToken === "err") {
        res.json({
            code: 201,
            msg: "请先登录"
        });
    } else {
        var phone = verifyToken.params.phone;
        User.findOne({ phone: phone }, (err, result) => {
            if (err) throw err
            let data = {
                movie: req.body.movieId,
                buyer: result._id,
                seat: req.body.seat
            }
            let newPay = new Pay(data);
            newPay.save((err, result) => {
                if (err) throw err
                User.findOneAndUpdate({ phone: phone }, { $push: { pay: result._id } }, (err) => {
                    if (err) throw err
                    res.json({
                        code: 200,
                        msg: "购买成功",
                        result: result
                    })
                })
            })
        })

    }
})
app.post("/myTicket", (req, res) => {
    User.findById(req.body.id, (err, result) => {
        if (err) throw err
        res.json({
            code: 200,
            pay: result.pay
        })
    })
})
app.post("/ticket", (req, res) => {
    Pay.findById(req.body.id, (err, result) => {
        if (err) throw err
        var seat = result.seat
        Movie.findById(result.movie, (err, data) => {
            if (err) throw err
            res.json({
                code: 200,
                movie: data,
                seat: seat
            })
        })
    })
})
//存储电影、演员信息

//预告
app.get("/advance", (req, res) => {
    Advance.find({}, (err, result) => {
        if (err) throw err
        res.json({
            code: 200,
            result: result
        })
    })
})

app.post("/other", (req, res) => {
    var id = mongoose.Types.ObjectId(req.body.id);
    User.findById(id, (err, result) => {
        if (err) throw err
        if (result == {}) {
            res.json({
                code: 201,
                msg: "该用户不存在"
            })
        } else {

            res.json({
                code: 200,
                name: result.name,
                type: result.type,
                introduce: result.introduce,
                headImg: result.headImg,
                backgroundImg: result.backgroundImg
            })
        }
        
    })
})
app.post("/like", (req, res) => {
    FilmReview.findByIdAndUpdate(req.body.id, { $inc: { like: 1 } }, (err, result) => {
        if (err) throw err
        res.json({
            code: 200,
            like: result.like
        })
    })
})

app.listen(3000, () => {
    console.log("访问http://127.0.0.1:3000")
})


